# csv_accessor.py
# CSVファイルの読み書きインターフェースを提供します。
