# Library System CLI

This repository contains a library management system including books, web articles, and media resources.

See `requirements_v2.1.md` for full system specification.