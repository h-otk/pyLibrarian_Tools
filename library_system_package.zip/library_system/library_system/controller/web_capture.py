# web_capture.py
# Web記事のスクリーンショット取得、HTML保存、テキスト抽出を行います。
