# media_model.py
# メディア資料（CD/DVD等）の構造を定義します。
