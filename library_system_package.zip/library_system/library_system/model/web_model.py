# web_model.py
# Web記事データ構造と関連ロジックを定義します。
